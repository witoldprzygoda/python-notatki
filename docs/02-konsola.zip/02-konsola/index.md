# 2. Konsola

Działania w interpreterze Pythona można prowadzić w dowolnym terminalu, zależnie od systemu operacyjnego. Przede wszystkim program interpretera powinien być widzialny (takie komendy, jak `whereis python` czy `which python`, pokazują co i gdzie jest zainstalowane).

Python można uruchomić w oknie **cmd** Windows (niewygodne), w **PowerShell** Windows, albo np. w programie **IDLE** (jeśli instalowało się Python jako cały pakiet). Warto przećwiczyć wykonanie kilku komend, aby się oswoić.

Nawet prosta funkcja `print` ma kilka opcji, np. w IDLE możemy zobaczyć podpowiedź podczas pisania.

<!-- TODO: screenshot — podpowiedź sygnatury print() w IDLE -->

!!! tip "Skróty klawiszowe w IDLE"
    IDLE ma niekoniecznie intuicyjny zestaw skrótów klawiszowych, który można
    przedefiniować lub się ich nauczyć. Przykładowo, poprzednia (kolejna)
    wykonana instrukcja to ++alt+p++ (++alt+n++).

## Funkcja print — pierwsze eksperymenty

Spróbujmy:

```{ .python .no-copy }
>>> print("hello world"*2, ' ', 123, 'tez string', sep=",", end=" ||KONIEC\n")
hello worldhello world, ,123,tez string ||KONIEC

>>> print('hello world', end=', '); print("yeah")
hello world, yeah
```

Z powyższych przykładów widać, że argumenty funkcji mogą mieć postać **argumentów pozycyjnych** bez nazwy oraz **nazwanych** (`sep`, `end`) — te można pisać w dowolnej kolejności (spróbuj zamienić `end` z `sep`). Widać też, że może być separator `;`, jeśli kolejna funkcja jest w tej samej linii.

## Typy dynamiczne, bool i None

Obiekty w Pythonie tworzy się dynamicznie, bez deklaracji typów — są zbudowane na podstawie wielkości inicjalizujących.

Przykładowo, typ logiczny `bool` ma dwie wartości opisane jako `True` oraz `False` (z wielkich liter), gdzie `True` umownie ma wartość 1, ale też wszystko, co nie jest zerem, obiektem pustym lub `None`, jest traktowane w kontekście logiki jako `True`.

```{ .python .no-copy }
>>> logika = True
>>> if logika:
...     print("to jest prawda")
```

!!! info "Słowo kluczowe None"
    Słowo kluczowe `None` służy do definiowania wartości null lub braku wartości.
    `None` to **nie** to samo co `0`, `False` lub pusty ciąg.
    `None` jest własnym typem danych (`NoneType`).

## Formatowanie kodu — wcięcia

Formatowanie kodu w Pythonie odbywa się za pomocą `:` (dwukropka) oraz odpowiednich wcięć. Do zrobienia wcięcia zaleca się użycie tabulacji, a nie spacji. Z drugiej strony warto tak skonfigurować tabulację, że wstawi ona określoną liczbę spacji, np. 4.

!!! tip "Tab size w Visual Studio Code"
    W Visual Studio Code (skrót ++ctrl+comma++) wpisując „tab size” znajdziemy
    odpowiednie pole, w którym wstawimy odpowiednią wartość.

**Nie można mieszać rodzaju wcięć.**

Nawet „na oko” dobrze sformatowany kod, jeśli ma pomieszane tabulacje i spacje, może być błędny. Żeby tego doświadczyć, trzeba oczywiście najpierw zapisać plik, w którym rzeczywiście jedno wcięcie będzie wypełnione znakiem Tab, a drugie zbudowane ze spacji. Można taką sytuację uzyskać np. pisząc fragment kodu w prostym edytorze typu Notatnik (Windows) i jedno wcięcie tworząc klawiszem ++tab++, a drugie wstawiając 8 spacji. Optycznie wygląda identycznie. Jednak po skopiowaniu takiego kodu do interpretera (np. okienko IDLE) zobaczymy błąd niekonsystencji znaków użytych we wcięciach.

## Komentarze

Komentarz jest na prawo od znaku `#`. Komentarz zapisany w wielu liniach osiąga się przez stworzenie wielolinijkowego łańcucha znakowego, bez jego przypisania. Tworzy się go za pomocą trzy razy powtórzonego pojedynczego `'''` lub podwójnego `"""` cudzysłowu.

```python
"""
To jest komentarz
zapisany w wielu liniach
"""
```

!!! tip "Komentowanie wielu linii w Visual Studio Code"
    Jeśli zaznaczymy kilka linijek kodu, to skrótem klawiszowym ++ctrl+k++ ++ctrl+c++
    (lub prościej ++ctrl+slash++) możemy dodać znak komentarza `#`,
    a skrótem ++ctrl+k++ ++ctrl+u++ go usunąć — w wielu liniach jednocześnie.

## Przypisanie wielokrotne

Zmienne można tworzyć, wykonując przypisanie wielu wartości jednocześnie, np.:

```{ .python .no-copy }
>>> x, y, z = 1, 2.5, "trzy"
```

## Konsola jako kalkulator

Konsolę można użyć jako kalkulatora. Spróbujmy:

```{ .python .no-copy }
>>> 2 + 2
>>> 50 - 5*6
>>> (50 - 5*6) / 4
>>> 8 / 5      # float, dzielenie prawdziwe
>>> 17 // 3    # dzielenie bez reszty
>>> 17 % 3     # modulo, czyli reszta z dzielenia
>>> 5 * 3 + 2
>>> 5 ** 2     # 5^2
>>> 2 ** 7     # 2^7
>>> width = 20
>>> height = 5 * 9
>>> width * height
```

Ostatnia wyświetlona w konsoli wartość jest dostępna również pod nazwą (znaczkiem) `_`:

```{ .python .no-copy }
>>> 5      # spróbuj (Enter)
>>> _
>>> _ + _
```

## Funkcje matematyczne

Aby mieć dostęp do większej liczby funkcji matematycznych, trzeba skorzystać z dodatkowych modułów. Przed użyciem moduł należy zaimportować. W tym przypadku:

```{ .python .no-copy }
>>> import math
>>> math.sqrt(4)
2.0
```

Spis funkcji: [docs.python.org/3/library/math.html](https://docs.python.org/3/library/math.html) — w przypadku liczb zespolonych użyjemy [cmath](https://docs.python.org/3/library/cmath.html).

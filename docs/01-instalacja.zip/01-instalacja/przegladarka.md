# Python w przeglądarce

Istnieje szereg serwisów, które umożliwiają pisanie i testowanie programów Pythona wprost w przeglądarce. Jest to wygodne rozwiązanie w przypadku, gdy akurat nie dysponujemy komputerem z odpowiednio zainstalowanym programem i środowiskiem. Dzięki temu możemy się uczyć praktycznie „zawsze i wszędzie”.

## Serwisy warte zainteresowania

- **Brython** — [brython.info](https://brython.info/tests/editor.html?lang=en)
- **Skulpt** — [skulpt.org](https://skulpt.org/)
- **Pyodide** — [pyodide.org](https://pyodide.org/en/latest/console.html)
- **Replit** — [replit.com](https://replit.com/)
